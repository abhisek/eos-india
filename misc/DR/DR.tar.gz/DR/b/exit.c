#include <stdio.h>
#include <stdlib.h>

main()
{
   __asm__(
      "xorl %eax, %eax\n"
      "incl %eax\n"
      "movl $666, %ebx\n"
      "int $0x80\n"
   );
}
