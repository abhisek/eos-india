$:.unshift("../")
require 'libnids'

def callback(opts = nil, ss = nil)
   return unless opts

   case opts["nids_state"]
      when NIDS::STATE_JUST_EST
         
      when NIDS::STATE_DATA
         puts opts["client_data"][opts["client_data_offset"],opts["client_data_new_len"]]
         puts ""
         puts opts["server_data"][opts["server_data_offset"],opts["server_data_new_len"]]
         
      when NIDS::STATE_CLOSE, NIDS::STATE_RESET
         
   end
end

conf = Hash.new
conf["pcap_filter"] = "port 80"
l = NIDS::Sniffer.new(conf)
l.register_tcp(self, :callback)
l.run

