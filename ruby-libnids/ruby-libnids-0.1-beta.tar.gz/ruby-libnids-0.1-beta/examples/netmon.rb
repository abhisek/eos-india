require 'libnids'
require 'ncurses'

class Display
   def initialize(hash_size = 50)
      @hash_size = hash_size
      @hash = Hash.new
   end

   def make_hash_key(tcp_stream = {})
      key = String.new
      key << tcp_stream['saddress']
      key << tcp_stream['daddress']
      key << tcp_stream['sport'].to_s
      key << tcp_stream['dport'].to_s

      return key
   end

   def print()
      str = String.new
      @hash.each do |key,val|
         str << "#{val['src_addr']}:#{val['src_port']}\t --> \t#{val['dest_addr']}:#{val['dest_port']}\t\t [SEND: #{val['write_bytes']}\t\t RECV: #{val['read_bytes']}]"
         str << "\n"
      end

      Ncurses.mvaddstr(0,0,str)
      Ncurses.refresh
   end

   def add_hash(tcp_stream = {})
      key = make_hash_key(tcp_stream)
      @hash[key] = {
         'src_addr'     => tcp_stream['saddress'],
         'dest_addr'    => tcp_stream['daddress'],
         'src_port'     => tcp_stream['sport'],
         'dest_port'    => tcp_stream['dport'],
         'read_bytes'   => tcp_stream['client_data_len'],
         'write_bytes'  => tcp_stream['server_data_len'],
         'state'        => tcp_stream['nids_state']
      }
   end

   def delete_hash(tcp_stream = {})
      key = make_hash_key(tcp_stream)
      @hash.delete(key)
   end
   
end

class Netmon

   def initialize()
      @disp = Display.new
   end

   def tcp_callback(tcp_stream = nil, dummy = nil)
   
      case tcp_stream['nids_state']
         when NIDS::STATE_DATA
            @disp.add_hash(tcp_stream)
            @disp.print
         when NIDS::STATE_RESET, NIDS::STATE_CLOSE, NIDS::STATE_TIMED_OUT, NIDS::STATE_EXITING
            @disp.delete_hash(tcp_stream)
            @disp.print
         else
            return
      end
   
   end

   def start
      nids = NIDS::Sniffer.new("pcap_filter" => "tcp")
      nids.register_tcp(self, :tcp_callback)
      nids.run
   end

end

Signal.trap("INT") do
   Ncurses.endwin
   puts "SigINT Trapped"
   exit
end

Ncurses.initscr
begin
   Netmon.new().start
rescue
   Ncurses.endwin
end
   
