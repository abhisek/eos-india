require 'mkmf'

if have_library('nids') and have_header('nids.h') 
   create_makefile('libnids')
else
   puts "Dependency failed"
end
   
