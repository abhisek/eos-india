/* 
 * Copyright (c) 2006 Abhisek Datta <abhisek@rubyforge.org>
 * All rights reserved.
 *
 * Redistribution and use in source and binary form, with or without
 * modification may not be used for commercial purposes in any way without
 * written permission from the author including but is not limited to products,
 * training, and consulting.
 *
 * Redistribution and use in source and binary form, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * Redistributions of source code or binaries must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND COPYRIGHT
 * HOLDERS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */

#define DEBUG
#include <ruby.h>
#include <nids.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>

#ifdef DEBUG
#define DEBUG_PRINT(x, ...)                                                   \
      ((RTEST(ruby_debug) && RTEST(ruby_verbose))?                            \
      (fprintf(stderr, "libnids: "x"\n", ##__VA_ARGS__),fflush(stderr)) : 0)
#else
#define DEBUG_PRINT(x, ...) (0)
#endif

extern struct nids_prm nids_params;
extern char nids_errbuf[];

VALUE cLibnids;
VALUE mLibnids;
static VALUE rb_object_ip_frag_cb = (VALUE) NULL;
static VALUE rb_object_ip_frag_cb_klass = (VALUE) NULL;
static VALUE rb_object_ip_cb = (VALUE) NULL;
static VALUE rb_object_ip_cb_klass = (VALUE) NULL;
static VALUE rb_object_tcp_cb = (VALUE) NULL;
static VALUE rb_object_tcp_cb_klass = (VALUE) NULL;
static VALUE rb_object_udp_cb = (VALUE) NULL;
static VALUE rb_object_udp_cb_klass = (VALUE) NULL;

static VALUE libnids_init(int argc, VALUE *argv, VALUE self)
{
   VALUE v = Qnil;
   VALUE opts = Qnil;

   DEBUG_PRINT("Initializing");

   if(argc > 0) 
      opts = argv[0];

   if(TYPE(opts) != T_NIL && TYPE(opts) != T_HASH)
      rb_raise(rb_eTypeError, "libnids_init: expected hash object");

   if(TYPE(opts) == T_HASH) {
      v = rb_hash_aref(opts, rb_str_new2("n_tcp_streams"));
      if(TYPE(v) == T_FIXNUM)
         nids_params.n_tcp_streams = INT2FIX(v);

      v = rb_hash_aref(opts, rb_str_new2("n_hosts"));
      if(TYPE(v) == T_FIXNUM)
         nids_params.n_hosts = INT2FIX(v);

      v = rb_hash_aref(opts, rb_str_new2("device"));
      if(TYPE(v) == T_STRING)
         nids_params.device = StringValuePtr(v);
   
      v = rb_hash_aref(opts, rb_str_new2("sk_buff_size"));
      if(TYPE(v) == T_FIXNUM)
         nids_params.sk_buff_size = INT2FIX(v);

      v = rb_hash_aref(opts, rb_str_new2("dev_addon"));
      if(TYPE(v) == T_FIXNUM)
         nids_params.dev_addon = INT2FIX(v);

      v = rb_hash_aref(opts, rb_str_new2("scan_num_hosts"));
      if(TYPE(v) == T_FIXNUM)
         nids_params.scan_num_hosts = INT2FIX(v);

      v = rb_hash_aref(opts, rb_str_new2("scan_num_ports"));
      if(TYPE(v) == T_FIXNUM)
         nids_params.scan_num_ports = INT2FIX(v);

      v = rb_hash_aref(opts, rb_str_new2("scan_delay"));
      if(TYPE(v) == T_FIXNUM)
         nids_params.scan_delay = INT2FIX(v);

      v = rb_hash_aref(opts, rb_str_new2("pcap_filter"));
      if(TYPE(v) == T_STRING)
         nids_params.pcap_filter = StringValuePtr(v);

      v = rb_hash_aref(opts, rb_str_new2("promisc"));
      if(TYPE(v) == T_FIXNUM)
         nids_params.promisc = INT2FIX(v);

      v = rb_hash_aref(opts, rb_str_new2("one_loop_less"));
      if(TYPE(v) == T_FIXNUM)
         nids_params.one_loop_less = INT2FIX(v);
   }

   nids_init();
   
   return self;
}

static void libnids_internal_register_ip_frag(struct ip *pkt)
{
   VALUE ip_pkt;
   char *p;

   DEBUG_PRINT("IP frag callback triggered");

   if(rb_object_ip_frag_cb == (VALUE) NULL || rb_object_ip_frag_cb_klass == (VALUE) NULL) {
      DEBUG_PRINT("IP frag callback method not set");
      return;
   }

   p = ruby_xmalloc(pkt->ip_hl << 2);
   if(p == NULL)
      rb_memerror();

   memcpy(p, pkt, pkt->ip_hl << 2);
   ip_pkt = rb_str_new2("");
   ip_pkt = rb_str_cat(ip_pkt, p, pkt->ip_hl << 2);

   rb_funcall(rb_object_ip_frag_cb_klass, 
         rb_intern("send"),
         2,
         rb_object_ip_frag_cb,
         ip_pkt);

   ruby_xfree(p);
   
   return;
}

static VALUE libnids_register_ip_frag(VALUE self, VALUE klass, VALUE cbFunc)
{
   DEBUG_PRINT("Registering IP frag callback");

   rb_object_ip_frag_cb_klass = klass;
   rb_object_ip_frag_cb = cbFunc;
   nids_register_ip_frag(&libnids_internal_register_ip_frag);
   
   return Qnil;
}

static void libnids_internal_register_ip(struct ip *pkt)
{
   VALUE ip_pkt;
   char *p;

   DEBUG_PRINT("IP callback triggered");

   if(rb_object_ip_cb == (VALUE) NULL || rb_object_ip_cb_klass == (VALUE) NULL) {
      DEBUG_PRINT("IP callback method not set");
      return;
   }

   p = ruby_xmalloc(pkt->ip_hl << 2);
   if(p == NULL)
      rb_memerror();

   memcpy(p, pkt, pkt->ip_hl << 2);
   ip_pkt = rb_str_new2("");
   ip_pkt = rb_str_cat(ip_pkt, p, pkt->ip_hl << 2);

   rb_funcall(rb_object_ip_cb_klass, 
         rb_intern("send"),
         2,
         rb_object_ip_cb,
         ip_pkt);

   ruby_xfree(p);
   
   return;
}

static VALUE libnids_register_ip(VALUE self, VALUE klass, VALUE cbFunc)
{
   DEBUG_PRINT("Registering IP callback");

   rb_object_ip_cb_klass = klass;
   rb_object_ip_cb = cbFunc;
   nids_register_ip(&libnids_internal_register_ip);

   return Qnil;
}

static void libnids_internal_register_udp(struct tuple4 *addr, u_char *data, int len, struct ip *pkt)
{
   VALUE src_addr;
   VALUE dst_addr;
   VALUE src_port;
   VALUE dst_port;
   VALUE payload;
   VALUE data_len;
   VALUE ip_pkt;
   VALUE hash;
   char *p;

   VALUE src_addr_key = rb_str_new2("");

   DEBUG_PRINT("UDP callback triggered");

   if(rb_object_udp_cb == (VALUE) NULL || rb_object_udp_cb_klass == (VALUE) NULL) {
      DEBUG_PRINT("UDP callback method not set");
      return;
   }

   src_addr = rb_str_new2((char*)inet_ntoa(*((struct in_addr*)&(addr->saddr))));
   dst_addr = rb_str_new2((char*)inet_ntoa(*((struct in_addr*)&(addr->daddr))));
   src_port = INT2FIX(addr->source);
   dst_port = INT2FIX(addr->dest);

   payload = rb_str_new2("");
   payload = rb_str_cat(payload, data, len);

   p = ruby_xmalloc(pkt->ip_hl << 2);
   if(p == NULL)
      rb_memerror();

   memcpy(p, pkt, pkt->ip_hl << 2);
   ip_pkt = rb_str_new2("");
   ip_pkt = rb_str_cat(ip_pkt, p, pkt->ip_hl << 2);

   hash = rb_hash_new();

   rb_hash_aset(hash, rb_str_new2("saddress"), src_addr);
   rb_hash_aset(hash, rb_str_new2("daddress"), dst_addr);
   rb_hash_aset(hash, rb_str_new2("sport"), src_port);
   rb_hash_aset(hash, rb_str_new2("dport"), dst_port);
   rb_hash_aset(hash, rb_str_new2("payload"), payload);
   rb_hash_aset(hash, rb_str_new2("payload_len"), len);
   rb_hash_aset(hash, rb_str_new2("ip_packet"), ip_pkt);


   rb_funcall(rb_object_udp_cb_klass, 
         rb_intern("send"),
         2,
         rb_object_udp_cb,
         hash);

   ruby_xfree(p);

   return;
}

static VALUE libnids_register_udp(VALUE self, VALUE klass, VALUE cbFunc)
{
   DEBUG_PRINT("Registering UDP callback");

   rb_object_udp_cb_klass = klass;
   rb_object_udp_cb = cbFunc;
   nids_register_udp(&libnids_internal_register_udp);

   return Qnil;
}

static void libnids_internal_register_tcp(struct tcp_stream *ts, void **param)
{
   VALUE client_data;
   VALUE client_data_offset;
   VALUE client_data_len;
   VALUE client_data_new_len;
   VALUE client_state;
   VALUE server_data;
   VALUE server_data_offset;
   VALUE server_data_len;
   VALUE server_data_new_len;
   VALUE server_state;
   VALUE nids_state;
   VALUE src_addr;
   VALUE dst_addr;
   VALUE src_port;
   VALUE dst_port;
   VALUE stream;
   VALUE hash;

   DEBUG_PRINT("TCP callback triggered");

   if(rb_object_tcp_cb == (VALUE) NULL || rb_object_tcp_cb_klass == (VALUE) NULL) {
      DEBUG_PRINT("TCP callback method not set");
      return;
   }

   stream = Data_Wrap_Struct(rb_cStruct, 
         0,
         0,
         ts);

   src_addr = rb_tainted_str_new2((char*)inet_ntoa(*((struct in_addr*)&(ts->addr.saddr))));
   dst_addr = rb_tainted_str_new2((char*)inet_ntoa(*((struct in_addr*)&(ts->addr.daddr))));
   src_port = INT2FIX(ts->addr.source);
   dst_port = INT2FIX(ts->addr.dest);
   
   client_data = rb_tainted_str_new2("");
   server_data = rb_tainted_str_new2("");
   client_data_offset = INT2FIX(0);
   client_data_len = INT2FIX(0);
   client_data_new_len = INT2FIX(0);
   server_data_offset = INT2FIX(0);
   server_data_len = INT2FIX(0);
   server_data_new_len = INT2FIX(0);

   nids_state = INT2FIX(ts->nids_state);
   client_state = INT2FIX(ts->client.state);
   server_state = INT2FIX(ts->server.state);

   switch(ts->nids_state) {
      case NIDS_JUST_EST:
         ts->client.collect++;
         ts->server.collect++;
         break;

      case NIDS_DATA:
      case NIDS_RESET:
      case NIDS_TIMED_OUT:
      case NIDS_EXITING:
      case NIDS_CLOSE:
         client_data = rb_str_cat(client_data, ts->client.data, ts->client.count);
         client_data_offset = INT2FIX(ts->client.offset);
         client_data_len = INT2FIX(ts->client.count);
         client_data_new_len = INT2FIX(ts->client.count_new);

         server_data = rb_str_cat(server_data, ts->server.data, ts->server.count);
         server_data_offset = INT2FIX(ts->server.offset);
         server_data_len = INT2FIX(ts->server.count);
         server_data_new_len = INT2FIX(ts->server.count_new);

         break;

      default:
         DEBUG_PRINT("Unknown nids state from TCP callback");
         return;
   }

   hash = rb_hash_new();
   
   rb_hash_aset(hash, rb_str_new2("saddress"), src_addr);
   rb_hash_aset(hash, rb_str_new2("daddress"), dst_addr);
   rb_hash_aset(hash, rb_str_new2("sport"), src_port);
   rb_hash_aset(hash, rb_str_new2("dport"), dst_port);
   rb_hash_aset(hash, rb_str_new2("nids_state"), nids_state);
   rb_hash_aset(hash, rb_str_new2("client_state"), client_state);
   rb_hash_aset(hash, rb_str_new2("client_data"), client_data);
   rb_hash_aset(hash, rb_str_new2("client_data_offset"), client_data_offset);
   rb_hash_aset(hash, rb_str_new2("client_data_len"), client_data_len);
   rb_hash_aset(hash, rb_str_new2("client_data_new_len"), client_data_new_len);
   rb_hash_aset(hash, rb_str_new2("server_state"), server_state);
   rb_hash_aset(hash, rb_str_new2("server_data"), server_data);
   rb_hash_aset(hash, rb_str_new2("server_data_offset"), server_data_offset);
   rb_hash_aset(hash, rb_str_new2("server_data_len"), server_data_len);
   rb_hash_aset(hash, rb_str_new2("server_data_new_len"), server_data_new_len);
   
   rb_funcall(rb_object_tcp_cb_klass,
         rb_intern("send"),
         3,
         rb_object_tcp_cb,
         hash,
         stream);

   return;
}

static VALUE libnids_register_tcp(VALUE self, VALUE klass, VALUE cbFunc)
{
   DEBUG_PRINT("Registering tcp callback");

   rb_object_tcp_cb_klass = klass;
   rb_object_tcp_cb = cbFunc;
   nids_register_tcp(&libnids_internal_register_tcp);
   
   return Qnil;
}

static VALUE libnids_run(VALUE self)
{
   DEBUG_PRINT("Starting to capture packet");
   
   if((getuid() == 0) || (geteuid() == 0))
      nids_run();
   else
      rb_raise(rb_eSecurityError, "Not enough privilege");

   DEBUG_PRINT("Error: nids_run() returned");
   
   return Qnil;
}

static VALUE libnids_discard(VALUE self, VALUE stream, VALUE count)
{
   struct tcp_stream *ts;

   DEBUG_PRINT("Discarding tcp packet");
   
   if(TYPE(stream) != T_STRUCT || TYPE(count) != T_FIXNUM) {
      raise(rb_eTypeError,"libnids_discard: expected struct object and fixnum");
   }

   Data_Get_Struct(stream, struct tcp_stream, ts);
   nids_discard(ts, NUM2INT(count));

   return Qnil;
}

static VALUE libnids_kill(VALUE self, VALUE stream)
{
   struct tcp_stream *ts;

   DEBUG_PRINT("Killing TCP stream");
   
   if(TYPE(stream) != T_STRUCT) {
      raise(rb_eTypeError,"libnids_discard: expected struct object");
   }

   Data_Get_Struct(stream, struct tcp_stream, ts);
   nids_killtcp(ts);

   return Qnil;
}

void Init_libnids()
{

   mLibnids = rb_define_module("NIDS");

   rb_define_const(mLibnids, "STATE_JUST_EST", INT2FIX(NIDS_JUST_EST));
   rb_define_const(mLibnids, "STATE_DATA", INT2FIX(NIDS_DATA));
   rb_define_const(mLibnids, "STATE_RESET", INT2FIX(NIDS_RESET));
   rb_define_const(mLibnids, "STATE_CLOSE", INT2FIX(NIDS_CLOSE));
   rb_define_const(mLibnids, "STATE_TIMED_OUT", INT2FIX(NIDS_TIMED_OUT));
   rb_define_const(mLibnids, "STATE_EXITING", INT2FIX(NIDS_EXITING));
   
   rb_define_const(mLibnids, "TCP_ESTABLISHED", INT2FIX(TCP_ESTABLISHED));
   rb_define_const(mLibnids, "TCP_SYN_SENT", INT2FIX(TCP_SYN_SENT));
   rb_define_const(mLibnids, "TCP_SYN_RECV", INT2FIX(TCP_SYN_RECV));
   rb_define_const(mLibnids, "TCP_FIN_WAIT1", INT2FIX(TCP_FIN_WAIT1));
   rb_define_const(mLibnids, "TCP_FIN_WAIT2", INT2FIX(TCP_FIN_WAIT2));
   rb_define_const(mLibnids, "TCP_TIME_WAIT", INT2FIX(TCP_TIME_WAIT));
   rb_define_const(mLibnids, "TCP_CLOSE", INT2FIX(TCP_CLOSE));
   rb_define_const(mLibnids, "TCP_CLOSE_WAIT", INT2FIX(TCP_CLOSE_WAIT));
   rb_define_const(mLibnids, "TCP_LAST_ACK", INT2FIX(TCP_LAST_ACK));
   rb_define_const(mLibnids, "TCP_LISTEN", INT2FIX(TCP_LISTEN));
   rb_define_const(mLibnids, "TCP_CLOSING", INT2FIX(TCP_CLOSING));

   cLibnids = rb_define_class_under(mLibnids, "Sniffer", rb_cObject);

   rb_define_method(cLibnids, "initialize", libnids_init, -1);
   rb_define_method(cLibnids, "register_ip_frag", libnids_register_ip_frag, 2);
   rb_define_method(cLibnids, "register_ip", libnids_register_ip, 2);
   rb_define_method(cLibnids, "register_tcp", libnids_register_tcp, 2);
   rb_define_method(cLibnids, "discard", libnids_discard, 1);
   rb_define_method(cLibnids, "kill", libnids_kill, 1);
   rb_define_method(cLibnids, "run", libnids_run, 0);

}
