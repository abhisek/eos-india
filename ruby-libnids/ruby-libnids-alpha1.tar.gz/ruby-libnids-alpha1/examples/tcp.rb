$:.unshift("../")
require 'libnids'

$l = 0

def callback(opts = nil, ss = nil)
   return unless opts

   case opts["nids_state"]
      when NIDS::STATE_JUST_EST
         puts "[NEW CONNECTION] #{opts['saddress']}:#{opts['sport']} --> #{opts['daddress']}:#{opts['dport']}"
         
      when NIDS::STATE_DATA
         puts "[DATA] #{opts['saddress']}:#{opts['sport']} --> #{opts['daddress']}:#{opts['dport']} [SEND: #{opts['server_data_len']}] [RECV: #{opts['client_data_len']}]"
         
      when NIDS::STATE_CLOSE, NIDS::STATE_RESET
         puts "[CLOSE] #{opts['saddress']}:#{opts['sport']} --> #{opts['daddress']}:#{opts['dport']}"
         
   end
end

$l = NIDS::Sniffer.new
$l.register_tcp(self, :callback)
$l.run

