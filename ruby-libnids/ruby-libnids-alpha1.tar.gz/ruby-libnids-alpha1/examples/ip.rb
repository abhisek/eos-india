$:.unshift("../")
require 'libnids'

def bin2str(ip)
   i = ip.dup

   i = i.unpack('V')[0]
   a = i & 0xFF
   b = (i >> 8) & 0xFF
   c = (i >> 16) & 0xFF
   d = (i >> 24) & 0xFF

   return "#{a}.#{b}.#{c}.#{d}"
end

def callback(pkt = nil)
   return unless pkt

   src_addr = pkt[12, 4]
   dst_addr = pkt[16, 4]
   src_addr = bin2str(src_addr)
   dst_addr = bin2str(dst_addr)

   puts "#{src_addr} --> #{dst_addr}"
end

l = NIDS::Sniffer.new
l.register_ip(self, :callback)
l.run

